#ifndef LIBRARIES_H
#define LIBRARIES_H
#pragma comment(lib, "ws2_32.lib")
#include <QMainWindow>
#include <QTableWidgetItem>
#include <vector>
#include <iostream>
#include <QtSql>
#include <regex>
#include <string>
#include <QDesktopServices>
#include <QUrl>
#include <winsock2.h>

#endif // LIBRARIES_H
#pragma warning(disable: 4996)

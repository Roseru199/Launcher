#include "mainwindow.h"
#include "updatewindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    /*
    UpdateWindow u;
    u.show();
     */

    return a.exec();
}

#include "joingamewindow.h"
#include "ui_joingamewindow.h"

JoinGameWindow::JoinGameWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::JoinGameWindow)
{
    ui->setupUi(this);
}

JoinGameWindow::~JoinGameWindow()
{
    delete ui;
}

void JoinGameWindow::on_joinButton_clicked()
{
    this->hide();
}



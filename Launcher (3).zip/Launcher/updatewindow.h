#ifndef UPDATEWINDOW_H
#define UPDATEWINDOW_H
#include "mainwindow.h"
#include <QWidget>

namespace Ui {
class UpdateWindow;
}

class UpdateWindow : public QWidget
{
    Q_OBJECT

public:
    explicit UpdateWindow(QWidget *parent = nullptr);
    ~UpdateWindow();
    void setProgressBarValue(int value);
    Ui::UpdateWindow *ui2;


};

#endif // UPDATEWINDOW_H

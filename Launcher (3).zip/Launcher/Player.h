#pragma once
#include "libraries.h"
class Player
{
private:

    QString nick;
    QString pass;
    QString country;
    QString language;
    QString community;
    QString tag_of_room;
    QString email;
    QString resreve_email;
    QString password;
    QString phone;
    long id;
	int rating;
	int num_of_win;
	int num_of_lose;
	int num_of_win_r;
	int num_of_lose_r;
	short kuy;
	short percent_of_win;
	short percent_of_win_r;
	short age;
public:

    Player();
    Player(long id, QString nick, QString pass, int rating, short kuy);
    ~Player();

    void setId(long id);
    void setNick(QString nick);
    void setCountry(QString country);
    void setCommunity(QString community);
    void setLanguage(QString language);
	void setKuy(short kuy);
	void setRating(int rating);

    QString getNick();
    QString getCountry();
    QString getCommuity();
	short getKuy();
	int getRating();
    long getId();
};


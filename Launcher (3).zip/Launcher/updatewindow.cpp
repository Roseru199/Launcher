#include "updatewindow.h"
#include "ui_updatewindow.h"

UpdateWindow::UpdateWindow(QWidget *parent) :
    QWidget(parent),
    ui2(new Ui::UpdateWindow)
{
    ui2->setupUi(this);

    setProgressBarValue(100);

}

UpdateWindow::~UpdateWindow()
{
    delete ui2;
}

void UpdateWindow::setProgressBarValue(int value)
{
    ui2->progressBar->setValue(100);
}

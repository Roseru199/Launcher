#ifndef INFOWINDOW_H
#define INFOWINDOW_H

#include <QWidget>



namespace Ui {
class InfoWindow;
}

class InfoWindow : public QWidget
{
    Q_OBJECT

public:
    explicit InfoWindow(QWidget *parent = nullptr);
    ~InfoWindow();
    int ratingI,winsI,defeatsI;
    short rateI;
    QString nickI;
private slots:
    void on_challengButton_clicked();
    void onButtonSend();

signals:
    void sendData(QString str);

private:
    Ui::InfoWindow *ui;
};

#endif // INFOWINDOW_H

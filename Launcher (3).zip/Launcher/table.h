#include <QTableWidget>
class Table : public QTableWidget
{
public:
    Table(QWidget *parent = nullptr) {}

Q_SIGNALS:
    void itemClicked(QTableWidgetItem *item);

};


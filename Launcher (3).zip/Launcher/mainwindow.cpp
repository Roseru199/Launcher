#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "updatewindow.h"
#include <windows.h>
#include "infowindow.h"
#include <QAbstractItemView>
#include "chatclient.h"
#include <QStandardItemModel>
#include <QInputDialog>
#include <QMessageBox>
#include <QHostAddress>
Player player;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_chatClient(new ChatClient(this))
    , m_chatModel(new QStandardItemModel(this))
{
    ui->setupUi(this);
    infoWindow = new InfoWindow();
    connect(infoWindow, SIGNAL(sendData(QString)), this, SLOT(recieveData(QString)));
    QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    QString connectString = "Driver={SQL Server};";
    connectString.append("Server=DESKTOP-TLR19BJ;");
    connectString.append("Database=PLAYERS;");
    //  connectString.append("Uid=admin;");
    //   connectString.append("Pwd=admin;");
    db.setDatabaseName(connectString);
    if (db.open())
    {

        cout << "Conetct"<<endl;
    }
    else cout << "Error connect to database" <<endl;

    ui->statusbar->hide();
    ui->shogiButton->setEnabled(false);
    ui->mainPageButton->setEnabled(false);
    ui->rulesButton->setEnabled(false);
    ui->communitiesButton->setEnabled(false);
    ui->playerRatingButton->setEnabled(false);
    ui->registration->setStyleSheet("background-color: rgba(0,0,0,0)");
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget_2->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->waitForGameTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    connect( ui->tableWidget, &QTableWidget::itemClicked, this, &MainWindow::onItemClicked );
    connect( ui->waitForGameTable, &QTableWidget::itemClicked, this, &MainWindow::onItemClicked2 );
    // the model for the messages will have 1 column
    m_chatModel->insertColumn(0);
    ui->listWidget->setModel(m_chatModel);

    // set the model as the data source vor the list view
    //ui->listWidget->setModel(m_chatModel);
    // connect the signals from the chat client to the slots in this ui
    connect(m_chatClient, &ChatClient::connected, this, &MainWindow::connectedToServer);
    connect(m_chatClient, &ChatClient::loggedIn, this, &MainWindow::loggedIn);
    connect(m_chatClient, &ChatClient::loginError, this, &MainWindow::loginFailed);
    connect(m_chatClient, &ChatClient::messageReceived, this, &MainWindow::messageReceived);
    connect(m_chatClient, &ChatClient::disconnected, this, &MainWindow::disconnectedFromServer);
    connect(m_chatClient, &ChatClient::error, this, &MainWindow::error);
    connect(m_chatClient, &ChatClient::userJoined, this, &MainWindow::userJoined);
    connect(m_chatClient, &ChatClient::userLeft, this, &MainWindow::userLeft);
    // connect the connect button to a slot that will attempt the connection

    // connect the click of the "send" button and the press of the enter while typing to the slot that sends the message
    connect(ui->sendButton, &QPushButton::clicked, this, &MainWindow::sendMessage);
    connect(ui->lineEdit, &QLineEdit::returnPressed, this, &MainWindow::sendMessage);

}

MainWindow::~MainWindow()
{
    delete ui;
}

bool isCorrectEmail(string email)
{
    regex re("(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$)");
    return regex_search(email, re);
}

bool iscapital(char x)
{
    if (x >= 'A' && x <= 'Z')
        return true;
    else
        return false;
}

bool valid(QString login,QString email, QString password, QString confirmPassword,Ui::MainWindow *ui)
{
    string str;
    str = email.toStdString();
    short counter =0;
    string s = password.toStdString();
    const char *a = s.c_str();
    bool valid;

        if  ( isCorrectEmail(str))
        {
            counter++;
            if(password.size()<50&&iscapital(a[0]))
            {

               if(login != "" && login != "Login" && login != "login" && email != "" && password != "" && confirmPassword != "" && password == confirmPassword)
                {
                    ui->errorBar->setText("All good");
                    return true;
                }
            }
            else ui->errorBar->setText("Password is not correct");
        }
        else ui->errorBar->setText("Mail is not correct");
    return false;
}

bool valid(QString email, QString password)
{
    short counter;
    bool valid;
    for(QString i: email)
    {
        if(i.toStdString() == "@" && counter != 0)
        {
            valid = true;
            break;
        }
        counter++;
    }
    if(valid &&  email != "" && password != "")
    {
        return true;
    }
    return false;
}

void online(QString nick, QString email)
{
    QString id,rating,rate;
    QSqlQuery query;
    QSqlQuery query1;

    query.prepare("SELECT ID, RATING, DAN FROM PLAYER WHERE EMAIL = :EMAIL AND NICK = :NICK");
    query.bindValue(":EMAIL", email);
    query.bindValue(":NICK", nick);
    query.exec();

    while (query.next())
    {
       id = query.value(0).toString();
       rating = query.value(1).toString();
       rate = query.value(2).toString();
       qDebug() << id << rating << rate;
    }

    query.prepare("INSERT INTO ONLINE_PLAYERS (PLAYER_ID, NICK, RATING, DAN) VALUES(:PLAYER_ID, :NICK, :RATING, :RATE)");
    query.bindValue(":PLAYER_ID", id);
    query.bindValue(":NICK", nick);
    query.bindValue(":RATING", rating);
    query.bindValue(":RATE", rate);
    query.exec();

    player.setId(id.toLong());
    player.setNick(nick);
    player.setRating(rating.toInt());
    player.setKuy(rate.toShort());
}

void MainWindow::on_registerButton_clicked()
{

    QString login = ui->login->text();
    QString email = ui->email->text();
    QString password = ui->password->text();
    QString confirmPassword = ui->confirmPassword->text();

    if(valid(login,email,password,confirmPassword,ui))
    {
        QSqlQuery query;
        query.prepare("INSERT INTO PLAYER (NICK, EMAIL, PASS, RATING, DAN) "
                          "VALUES (:NICK, :EMAIL, :PASS, :RATING, :RATE)");
        query.bindValue(":NICK", login);
        query.bindValue(":EMAIL", email);
        query.bindValue(":PASS", password);
        query.bindValue(":RATING", "0");
        query.bindValue(":RATE", "0");
        query.exec();

        ui->stackedWidget->setCurrentIndex(0);
        ui->shogiButton->setEnabled(true);
        ui->mainPageButton->setEnabled(true);
        ui->rulesButton->setEnabled(true);
        ui->communitiesButton->setEnabled(true);
        ui->playerRatingButton->setEnabled(true);
        online(login,email);

    }
}

void MainWindow::on_signInButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void MainWindow::on_signInButton_2_clicked()
{
    QString nick,pass;
    QString email_2 = ui->email_2->text();
    QString password_2 = ui->password_2->text();

    if(!isCorrectEmail(email_2.toStdString()))
    {
        QSqlQuery query;

        query.prepare("SELECT NICK, PASS FROM PLAYER WHERE EMAIL = :EMAIL");
        query.bindValue(":EMAIL", email_2);
        query.exec();
        while (query.next())
        {
           nick = query.value(0).toString();
           pass = query.value(1).toString();
           qDebug() << nick << pass;
        }
        if (pass == password_2)
        {
            ui->shogiButton->setEnabled(true);
            ui->mainPageButton->setEnabled(true);
            ui->rulesButton->setEnabled(true);
            ui->communitiesButton->setEnabled(true);
            ui->playerRatingButton->setEnabled(true);
            ui->stackedWidget->setCurrentIndex(0);
            online(nick,email_2);
        }
        else
        {
            ui->errorBar_2->setText("Password is not correct");
        }
    }
    else ui->errorBar_2->setText("Mail is not correct");
}

void tableWdget(Ui::MainWindow *ui)
{
    ui->tableWidget->clear();
    QTableWidgetItem* item;
    QSqlQuery query;
    int i = 0;
    query.prepare("SELECT NICK, RATING, DAN FROM ONLINE_PLAYERS");
    query.exec();
    while (query.next())
    {
        ui->tableWidget->setRowCount(i + 1);
        item = new QTableWidgetItem;
        item->setText(query.value(0).toString());
        ui->tableWidget->setItem(i,0,item);
        item = new QTableWidgetItem;
        item->setText(query.value(1).toString());
        ui->tableWidget->setItem(i,1,item);
        item = new QTableWidgetItem;
        item->setText(query.value(2).toString());
        ui->tableWidget->setItem(i,2,item);
        i++;
    }
}

void MainWindow::on_playButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
    attemptConnection();
    tableWdget(ui);

}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QSqlQuery query;
    query.prepare("DELETE FROM ONLINE_PLAYERS WHERE PLAYER_ID = :ID");
    query.bindValue(":ID", QString::number(player.getId()));
    query.exec();
    query.prepare("DELETE WAITING_FOR_MATCH WHERE PLAYER = :NICK");
    query.bindValue(":NICK", player.getNick());
    query.exec();
}

void MainWindow::on_shogiButton_clicked()
{
  ui->stackedWidget->setCurrentIndex(4);
  ui->waitForGameTable->clear();
  attemptConnection();
  QTableWidgetItem* item;
  QSqlQuery query;
  int i = 0;
  query.prepare("SELECT PLAYER, TYPE_OF_MATCH, TIME_FORMAT FROM WAITING_FOR_MATCH");
  query.exec();
  while (query.next())
  {
      ui->waitForGameTable->setRowCount(i + 1);
      item = new QTableWidgetItem;
      item->setText(query.value(0).toString());
      ui->waitForGameTable->setItem(i,0,item);
      item = new QTableWidgetItem;
      item->setText(query.value(1).toString());
      ui->waitForGameTable->setItem(i,1,item);
      item = new QTableWidgetItem;
      item->setText(query.value(2).toString());
      ui->waitForGameTable->setItem(i,2,item);
      i++;
  }


  ui->tableWidget->clear();
  i = 0;
  query.prepare("SELECT NICK, RATING, DAN FROM ONLINE_PLAYERS");
  query.exec();
  while (query.next())
  {
      ui->tableWidget->setRowCount(i + 1);
      item = new QTableWidgetItem;
      item->setText(query.value(0).toString());
      ui->tableWidget->setItem(i,0,item);
      item = new QTableWidgetItem;
      item->setText(query.value(1).toString());
      ui->tableWidget->setItem(i,1,item);
      item = new QTableWidgetItem;
      item->setText(query.value(2).toString());
      ui->tableWidget->setItem(i,2,item);
      i++;
  }

}

void MainWindow::on_mainPageButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_playerRatingButton_clicked()
{
    QString link="https://system.81dojo.com/en/ranking";
    QDesktopServices::openUrl(QUrl(link));

}

void MainWindow::on_communitiesButton_clicked()
{
    QString link="https://system.81dojo.com/en/circles";
    QDesktopServices::openUrl(QUrl(link));

}

void MainWindow::on_rulesButton_clicked()
{
    QString link="http://shogi.by/shogi/1/";
    QDesktopServices::openUrl(QUrl(link));

}

void MainWindow::on_sendButton_clicked()
{
    if(ui->lineEdit->text() != "")
    {
       // ui->listWidget->addItem(player.getNick() + ": " + ui->lineEdit->text());

    }
}
void MainWindow::onItemClicked2( QTableWidgetItem * pItem )
{
    //j->show();
}


void MainWindow::onItemClicked( QTableWidgetItem * pItem )
{
    //infoWindow->show();
/*
    int wins, defeats;
    int i = ui->waitForGameTable->selectionModel()->currentIndex().row();

    int rating = ui->waitForGameTable->model()->index(i,1).data().toInt();
    short rate = ui->waitForGameTable->model()->index(i,2).data().toInt();



    //ui->tableView->model()->data(ui->tableView->currentIndex()). Нет?
    //QString nick = ui->waitForGameTable->model->data();
    QSqlQuery query;

    query.prepare("SELECT WINS, DEFEAT FROM PLAYER WHERE NICK = :PLAYER AND RATING = :RATING AND DAN = :RATE");
    query.bindValue(":NICK", nick);
    query.bindValue(":RATING", rating);
    query.bindValue(":RATE", rate);
    query.exec();
    query.next();
    wins = query.value(0).toInt();
    defeats = query.value(1).toInt();

    infoWindow->nickI = nick;
    infoWindow->ratingI = rating;
    infoWindow->rateI = rate;
    infoWindow->winsI = wins;
    infoWindow->defeatsI = defeats;*/
}

void MainWindow::on_modeButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

void MainWindow::on_play_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(4);
    ui->waitForGameTable->clear();
    QTableWidgetItem* item;
    QSqlQuery query;
    int i = 0;
/*
    //system("start C:\\Users\\Roseru\\Documents\\Shogi2\\x64\\Release\\Shogi.exe");
    QProcess process;
    //process.setWorkingDirectory("C:/Windows/Sysnative");
    process.start("C:\\Users\\Roseru\\Documents\\Shogi2\\x64\\Release\\Shogi.exe", QStringList{"volume", "protect", "C:"});
        process.waitForFinished(10000000000);*/
    query.prepare("SELECT PLAYER FROM WAITING_FOR_MATCH WHERE PLAYER = :PLAYER");
    query.bindValue(":PLAYER", player.getNick());
    query.exec();
    query.next();
    if(query.value(0).toString() != player.getNick())
    {
        if(ui->radioButton->isChecked())
        {
            QSqlQuery query;
            query.prepare("INSERT INTO WAITING_FOR_MATCH (PLAYER, TYPE_OF_MATCH, TIME_FORMAT) VALUES (:NICK, :TYPE_OF_MATCH, :TIME_FORMAT)");
            query.bindValue(":NICK", player.getNick());
            query.bindValue(":TYPE_OF_MATCH", "Ranked");
            query.bindValue(":TIME_FORMAT", "15min - 60sec, Rated (x1.21)");
            query.exec();
        }
        else if(ui->radioButton_2->isChecked())
        {
            QSqlQuery query;
            query.prepare("INSERT INTO WAITING_FOR_MATCH (PLAYER, TYPE_OF_MATCH, TIME_FORMAT) VALUES (:NICK, :TYPE_OF_MATCH, :TIME_FORMAT)");
            query.bindValue(":NICK", player.getNick());
            query.bindValue(":TYPE_OF_MATCH", "Ranked");
            query.bindValue(":TIME_FORMAT", "10min - 30sec, Rated (x1.11)");
            query.exec();
        }
        else if(ui->radioButton_3->isChecked())
        {
            QSqlQuery query;
            query.prepare("INSERT INTO WAITING_FOR_MATCH (PLAYER, TYPE_OF_MATCH, TIME_FORMAT) VALUES (:NICK, :TYPE_OF_MATCH, :TIME_FORMAT)");
            query.bindValue(":NICK", player.getNick());
            query.bindValue(":TYPE_OF_MATCH", "Ranked");
            query.bindValue(":TIME_FORMAT", "5min - 30sec, Rated (x1.00)");
            query.exec();
        }
        else if(ui->radioButton_4->isChecked())
        {
            QSqlQuery query;
            query.prepare("INSERT INTO WAITING_FOR_MATCH (PLAYER, TYPE_OF_MATCH, TIME_FORMAT) VALUES (:NICK, :TYPE_OF_MATCH, :TIME_FORMAT)");
            query.bindValue(":NICK", player.getNick());
            query.bindValue(":TYPE_OF_MATCH", "Ranked");
            query.bindValue(":TIME_FORMAT", "0min - 30sec, Rated (x0.85)");
            query.exec();
        }
        else if(ui->radioButton_5->isChecked())
        {
            QSqlQuery query;
            query.prepare("INSERT INTO WAITING_FOR_MATCH (PLAYER, TYPE_OF_MATCH, TIME_FORMAT) VALUES (:NICK, :TYPE_OF_MATCH, :TIME_FORMAT)");
            query.bindValue(":NICK", player.getNick());
            query.bindValue(":TYPE_OF_MATCH", "UnRanked");
            query.bindValue(":TIME_FORMAT", "");
            query.exec();
        }
        else
        {

        }
    }
    else
    {

    }
    ui->stackedWidget->setCurrentIndex(4);

    ui->waitForGameTable->clear();
    query.prepare("SELECT PLAYER, TYPE_OF_MATCH, TIME_FORMAT FROM WAITING_FOR_MATCH");
    query.exec();


    while (query.next())
    {

        /*
        for(int a = 0;a <= ui->waitForGameTable->rowCount();a++)
        {
            QItemSelectionModel *select = ui->waitForGameTable->selectionModel();
            //rowidx = ui->waitForGameTable->selectionModel()->currentIndex().row();
            if(query.value(0).toString() == select->selectedRows(a).value(0).data().toString()) query.next();
            //ui->txt1->setText(model->index(rowidx , 0).data().toString());
        }*/
        //if(query.value(0).toString() == ui->waitForGameTable->rowCount())
        ui->waitForGameTable->setRowCount(i + 1);
        item = new QTableWidgetItem;
        item->setText(query.value(0).toString());
        ui->waitForGameTable->setItem(i,0,item);
        item = new QTableWidgetItem;
        item->setText(query.value(1).toString());
        ui->waitForGameTable->setItem(i,1,item);
        item = new QTableWidgetItem;
        item->setText(query.value(2).toString());
        ui->waitForGameTable->setItem(i,2,item);
        i++;

        i = 0;

        ui->tableWidget->clear();
        QTableWidgetItem* item;
        QSqlQuery query;
        int i = 0;
        query.prepare("SELECT NICK, RATING, DAN FROM ONLINE_PLAYERS");
        query.exec();
        while (query.next())
        {
            ui->tableWidget->setRowCount(i + 1);
            item = new QTableWidgetItem;
            item->setText(query.value(0).toString());
            ui->tableWidget->setItem(i,0,item);
            item = new QTableWidgetItem;
            item->setText(query.value(1).toString());
            ui->tableWidget->setItem(i,1,item);
            item = new QTableWidgetItem;
            item->setText(query.value(2).toString());
            ui->tableWidget->setItem(i,2,item);
            i++;
        }
    }

}

void MainWindow::recieveData(QString str)
{
}
void MainWindow::attemptConnection()
{
    // We ask the user for the address of the server, we use 127.0.0.1 (aka localhost) as default
    const QString hostAddress = "127.0.0.1";

    // disable the connect button to prevent the user clicking it again
    ui->connectButton->setEnabled(false);
    // tell the client to connect to the host using the port 1967
    m_chatClient->connectToServer(QHostAddress(hostAddress), 1967);
}

void MainWindow::connectedToServer()
{
    // once we connected to the server we ask the user for what username they would like to use
    const QString newUsername = player.getNick();
    if (newUsername.isEmpty()){
        // if the user clicked cancel or typed nothing, we just disconnect from the server
        return m_chatClient->disconnectFromHost();
    }
    // try to login with the given username
    attemptLogin(newUsername);
}

void MainWindow::attemptLogin(const QString &userName)
{
    // use the client to attempt a log in with the given username
    m_chatClient->login(userName);
}

void MainWindow::loggedIn()
{
    // once we successully log in we enable the ui to display and send messages
    ui->sendButton->setEnabled(true);
    ui->lineEdit->setEnabled(true);
    ui->listWidget->setEnabled(true);
    // clear the user name record
    m_lastUserName.clear();
}

void MainWindow::loginFailed(const QString &reason)
{
    // the server rejected the login attempt
    // display the reason for the rejection in a message box
    //QMessageBox::critical(this, tr("Error"), reason);
    // allow the user to retry, execute the same slot as when just connected
    connectedToServer();
}

void MainWindow::messageReceived(const QString &sender, const QString &text)
{
    // store the index of the new row to append to the model containing the messages
    int newRow = m_chatModel->rowCount();
    // we display a line containing the username only if it's different from the last username we displayed
    if (m_lastUserName != sender) {
        // store the last displayed username
        m_lastUserName = sender;
        // create a bold default font
        QFont boldFont;
        boldFont.setBold(true);
        // insert 2 row, one for the message and one for the username
        m_chatModel->insertRows(newRow, 2);
        // store the username in the model
        m_chatModel->setData(m_chatModel->index(newRow, 0), sender + QLatin1Char(':'));
        // set the alignment for the username
        m_chatModel->setData(m_chatModel->index(newRow, 0), int(Qt::AlignLeft | Qt::AlignVCenter), Qt::TextAlignmentRole);
        // set the for the username
        m_chatModel->setData(m_chatModel->index(newRow, 0), boldFont, Qt::FontRole);
        ++newRow;
    } else {
        // insert a row for the message
        m_chatModel->insertRow(newRow);
    }
    // store the message in the model
    m_chatModel->setData(m_chatModel->index(newRow, 0), text);
    // set the alignment for the message
    m_chatModel->setData(m_chatModel->index(newRow, 0), int(Qt::AlignLeft | Qt::AlignVCenter), Qt::TextAlignmentRole);
    // scroll the view to display the new message
    ui->listWidget->scrollToBottom();
}

void MainWindow::sendMessage()
{
    // we use the client to send the message that the user typed
    m_chatClient->sendMessage(ui->lineEdit->text());
    // now we add the message to the list
    // store the index of the new row to append to the model containing the messages
    const int newRow = m_chatModel->rowCount();
    // insert a row for the message
    m_chatModel->insertRow(newRow);
    // store the message in the model
    m_chatModel->setData(m_chatModel->index(newRow, 0), ui->lineEdit->text());
    // set the alignment for the message
    m_chatModel->setData(m_chatModel->index(newRow, 0), int(Qt::AlignRight | Qt::AlignVCenter), Qt::TextAlignmentRole);
    // clear the content of the message editor
    ui->lineEdit->clear();
    // scroll the view to display the new message
    ui->listWidget->scrollToBottom();
    // reset the last printed username
    m_lastUserName.clear();
}

void MainWindow::disconnectedFromServer()
{
    // if the client loses connection to the server
    // comunicate the event to the user via a message box
    //QMessageBox::warning(this, tr("Disconnected"), tr("The host terminated the connection"));
    // disable the ui to send and display messages
    ui->sendButton->setEnabled(false);
    ui->lineEdit->setEnabled(false);
    ui->listWidget->setEnabled(false);
    // enable the button to connect to the server again
    ui->connectButton->setEnabled(true);
    // reset the last printed username
    m_lastUserName.clear();
}

void MainWindow::userJoined(const QString &username)
{
    // store the index of the new row to append to the model containing the messages
    const int newRow = m_chatModel->rowCount();
    // insert a row
    m_chatModel->insertRow(newRow);
    // store in the model the message to comunicate a user joined
    m_chatModel->setData(m_chatModel->index(newRow, 0), tr("%1 Joined the Chat").arg(username));
    // set the alignment for the text
    m_chatModel->setData(m_chatModel->index(newRow, 0), Qt::AlignCenter, Qt::TextAlignmentRole);
    // set the color for the text
    m_chatModel->setData(m_chatModel->index(newRow, 0), QBrush(Qt::blue), Qt::ForegroundRole);
    // scroll the view to display the new message
    ui->listWidget->scrollToBottom();
    // reset the last printed username
    m_lastUserName.clear();
}
void MainWindow::userLeft(const QString &username)
{
    // store the index of the new row to append to the model containing the messages
    const int newRow = m_chatModel->rowCount();
    // insert a row
    m_chatModel->insertRow(newRow);
    // store in the model the message to comunicate a user left
    m_chatModel->setData(m_chatModel->index(newRow, 0), tr("%1 Left the Chat").arg(username));
    // set the alignment for the text
    m_chatModel->setData(m_chatModel->index(newRow, 0), Qt::AlignCenter, Qt::TextAlignmentRole);
    // set the color for the text
    m_chatModel->setData(m_chatModel->index(newRow, 0), QBrush(Qt::red), Qt::ForegroundRole);
    // scroll the view to display the new message
    ui->listWidget->scrollToBottom();
    // reset the last printed username
    m_lastUserName.clear();
}

void MainWindow::error(QAbstractSocket::SocketError socketError)
{
    // show a message to the user that informs of what kind of error occurred
    switch (socketError) {
    case QAbstractSocket::RemoteHostClosedError:
    case QAbstractSocket::ProxyConnectionClosedError:
        return; // handled by disconnectedFromServer
    case QAbstractSocket::ConnectionRefusedError:
        //QMessageBox::critical(this, tr("Error"), tr("The host refused the connection"));
        break;
    case QAbstractSocket::ProxyConnectionRefusedError:
        //QMessageBox::critical(this, tr("Error"), tr("The proxy refused the connection"));
        break;
    case QAbstractSocket::ProxyNotFoundError:
        //QMessageBox::critical(this, tr("Error"), tr("Could not find the proxy"));
        break;
    case QAbstractSocket::HostNotFoundError:
       // QMessageBox::critical(this, tr("Error"), tr("Could not find the server"));
        break;
    case QAbstractSocket::SocketAccessError:
        //QMessageBox::critical(this, tr("Error"), tr("You don't have permissions to execute this operation"));
        break;
    case QAbstractSocket::SocketResourceError:
        //QMessageBox::critical(this, tr("Error"), tr("Too many connections opened"));
        break;
    case QAbstractSocket::SocketTimeoutError:
        //QMessageBox::warning(this, tr("Error"), tr("Operation timed out"));
        return;
    case QAbstractSocket::ProxyConnectionTimeoutError:
        //QMessageBox::critical(this, tr("Error"), tr("Proxy timed out"));
        break;
    case QAbstractSocket::NetworkError:
        //QMessageBox::critical(this, tr("Error"), tr("Unable to reach the network"));
        break;
    case QAbstractSocket::UnknownSocketError:
        //QMessageBox::critical(this, tr("Error"), tr("An unknown error occured"));
        break;
    case QAbstractSocket::UnsupportedSocketOperationError:
        //QMessageBox::critical(this, tr("Error"), tr("Operation not supported"));
        break;
    case QAbstractSocket::ProxyAuthenticationRequiredError:
       // QMessageBox::critical(this, tr("Error"), tr("Your proxy requires authentication"));
        break;
    case QAbstractSocket::ProxyProtocolError:
        //QMessageBox::critical(this, tr("Error"), tr("Proxy comunication failed"));
        break;
    case QAbstractSocket::TemporaryError:
    case QAbstractSocket::OperationError:
       // QMessageBox::warning(this, tr("Error"), tr("Operation failed, please try again"));
        return;
    default:
        Q_UNREACHABLE();
    }
    // enable the button to connect to the server again
    ui->connectButton->setEnabled(true);
    // disable the ui to send and display messages
    ui->sendButton->setEnabled(false);
    ui->lineEdit->setEnabled(false);
    ui->listWidget->setEnabled(false);
    // reset the last printed username
    m_lastUserName.clear();
}

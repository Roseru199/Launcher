#include "Player.h"
Player::Player()
{

}
Player::Player(long id, QString nick, QString pass, int rating, short kuy)
{
    this->id = id;
    this->nick = nick;
    this->pass = pass;
    this->rating = rating;
    this->kuy = kuy;
}
Player::~Player()
{

}
void Player::setId(long id)
{
    this->id = id;
}

void Player::setNick(QString nick)
{
	this->nick = nick;
}

void Player::setCountry(QString country)
{
	this->country = country;
}

void Player::setCommunity(QString community)
{
	this->community = community;
}

void Player::setLanguage(QString language)
{
	this->language = language;
}

void Player::setKuy(short kuy)
{
	this->kuy = kuy;
}

void Player::setRating(int rating)
{
	this->rating = rating;
}

QString Player::getNick()
{
	return nick;
}

QString Player::getCountry()
{
	return country;
}

QString Player::getCommuity()
{
	return community;
}

int Player::getRating()
{
	return rating;
}

short Player::getKuy()
{
	return kuy;
}

long Player::getId()
{
    return id;
}

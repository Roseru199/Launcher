#ifndef JOINGAMEWINDOW_H
#define JOINGAMEWINDOW_H

#include <QWidget>

namespace Ui {
class JoinGameWindow;
}

class JoinGameWindow : public QWidget
{
    Q_OBJECT

public:
    explicit JoinGameWindow(QWidget *parent = nullptr);
    ~JoinGameWindow();

private slots:
    void on_joinButton_clicked();

private:
    Ui::JoinGameWindow *ui;
};

#endif // JOINGAMEWINDOW_H

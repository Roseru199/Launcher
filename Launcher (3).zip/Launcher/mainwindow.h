#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include "Player.h"
#include "updatewindow.h"
#include "infowindow.h"
#include "chatclient.h"
#include "joingamewindow.h"
#include <QAbstractSocket>
using namespace std;
QT_BEGIN_NAMESPACE
class ChatClient;
class QStandardItemModel;
namespace Ui { class MainWindow; }
QT_END_NAMESPACE


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots:
    void onItemClicked( QTableWidgetItem * pItem );
    void onItemClicked2( QTableWidgetItem * pItem );

    void recieveData(QString str);
    void on_registerButton_clicked();
    void on_signInButton_clicked();
    void on_signInButton_2_clicked();

    void on_playButton_clicked();

    void on_shogiButton_clicked();

    void on_mainPageButton_clicked();

    void on_playerRatingButton_clicked();

    void on_communitiesButton_clicked();

    void on_rulesButton_clicked();
    void on_sendButton_clicked();

    void on_modeButton_clicked();

    void on_play_2_clicked();







    void attemptConnection();
    void connectedToServer();
    void attemptLogin(const QString &userName);
    void loggedIn();
    void loginFailed(const QString &reason);
    void messageReceived(const QString &sender, const QString &text);
    void sendMessage();
    void disconnectedFromServer();
    void userJoined(const QString &username);
    void userLeft(const QString &username);
    void error(QAbstractSocket::SocketError socketError);

private:
    Ui::MainWindow *ui;
    //UpdateWindow* updateWindow;
    JoinGameWindow* j;
    InfoWindow* infoWindow;
    ChatClient *m_chatClient;
    QStandardItemModel *m_chatModel;
    QString m_lastUserName;
    void closeEvent(QCloseEvent *event);
};

#endif // MAINWINDOW_H

#include "infowindow.h"
#include "ui_infowindow.h"

InfoWindow::InfoWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::InfoWindow)
{
    ui->setupUi(this);
    connect(ui->challengButton, SIGNAL(clicked()), this, SLOT(onButtonSend()));
    ui->niclInfo->setText(nickI);
    ui->ratingInfo->setText(QString::number(ratingI));
    ui->rateInfo->setText(QString::number(rateI));
    ui->winsInfo->setText(QString::number(winsI));
    ui->losesInfo->setText(QString::number(defeatsI));
}

InfoWindow::~InfoWindow()
{
    delete ui;
}

void InfoWindow::on_challengButton_clicked()
{
    this->hide();
}
void InfoWindow::onButtonSend()
{
    emit sendData(""); // вызываем сигнал, в котором передаём введённые данные
}

